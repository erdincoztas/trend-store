const products = [
    {
      id: 1,
      name: "Ürün 1",
      description: "Ürün 1'in açıklaması",
      img: "/images/image-1.png",
      price: 100.0,
      amount: 1,
    },
    {
      id: 2,
      name: "Ürün 2",
      description: "Ürün 2'nin açıklaması",
      img: "/images/image-2.png",
      price: 150.0,
      amount: 1,
    },
    {
      id: 3,
      name: "Ürün 3",
      description: "Ürün 3'ün açıklaması",
      img: "/images/image-3.png",
      price: 200.0,
      amount: 1,
    },
    {
      id: 4,
      name: "Ürün 4",
      description: "Ürün 4'ün açıklaması",
      img: "/images/image-4.png",
      price: 250.0,
      amount: 1,
    },
  ];
  
  export default products